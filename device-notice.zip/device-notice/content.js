const host = document.createElement('div');
const root = host.attachShadow({ mode: 'closed' });
root.innerHTML = `
<style>
  .bar {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    height: 22px;
    z-index: 2147483647;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #e5e7eb;
    color: #374151;
    font: 12px/1 system-ui, sans-serif;
    border-bottom: 1px solid #d1d5db;
  }
  a { color: #1d4ed8; margin-left: 6px; }
</style>
<div class="bar">
  This device is monitored.
  <a href="https://example.com/acceptable-use" target="_blank">Policy</a>
</div>`;
document.documentElement.appendChild(host);
document.documentElement.style.setProperty('margin-top', '22px', 'important');
